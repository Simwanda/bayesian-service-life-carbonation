# Reliability analysis from posterior fits, sigma_epsilon = 2.5 mm

This package contains a MATLAB script to run the updated reliability analysis using the posterior distribution fits from the Bayesian updating case with observation-error standard deviation `sigma_epsilon = 2.5 mm`.

## Main script

```matlab
run_reliability_posterior_fits_25mm
```

Run it from the root folder of the Bayesian carbonation repository, where `carbonation_xc_table2.m` is available.

## What it does

The script:

1. Samples the posterior fitted distributions for the fib and Malami models.
2. Uses bounded-power CDFs for the bounded variables:
   - fib `tc`: \(a=1\), \(b=3\), \(\gamma=0.7209\)
   - fib `pSR`: \(a=0.05\), \(b=0.25\), \(\gamma=0.7597\)
   - Malami `tc`: \(a=1\), \(b=3\), \(\gamma=0.8320\)
   - Malami `pSR`: \(a=0.05\), \(b=0.25\), \(\gamma=0.7395\)
3. Computes time-dependent reliability curves for:
   - fib Case I
   - fib Case II
   - Malami Case I
   - Malami Case II
4. Computes MCS and FORM results at \(t=42\) years.
5. Computes FORM importance factors at \(t=42\) years.
6. Produces figures similar to Figures 9--11.

## Limit state

\[
g(t) = C_r - x_c(t)
\]

Failure/depassivation occurs when \(g(t) \leq 0\).

## Cover cases

- Case I: deterministic cover \(C_r = 20.5\) mm
- Case II: stochastic cover \(C_r \sim \mathrm{Lognormal}(20.5\text{ mm}, \mathrm{CoV}=0.30)\)

## Important note

Do **not** add `sigma_epsilon = 2.5 mm` again in the reliability analysis. It was already used in the Bayesian likelihood to generate the posterior distributions.

## Outputs

The script creates:

```text
figs_reliability_posterior_25mm/
  Figure9_reliability_beta_time.pdf
  Figure9_reliability_beta_time.png
  Figure10_FORM_importance_basic.pdf
  Figure10_FORM_importance_basic.png
  Figure11_FORM_importance_An.pdf
  Figure11_FORM_importance_An.png
  Table5_reliability_results_42years.csv
  reliability_curves.csv
  FORM_importance_basic_42years.csv
  FORM_importance_An_42years.csv
```

## Final run

For a quick test, the script uses `Nmc = 300000`.  
For final paper-quality MCS estimates, increase this line in the script:

```matlab
Nmc = 1000000;
```
